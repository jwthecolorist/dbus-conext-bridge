#!/bin/sh
# Conext Bridge boot-time setup (runs on every boot via rc.local)
INSTALL_DIR="/data/dbus-conext-bridge"
DBUS_CMD="dbus -y com.victronenergy.settings /Settings"
QML_DIR="/opt/victronenergy/gui/qml"

logger "conext-bridge: Running setup..."

# 1. Service symlink (/service is tmpfs, recreated each boot)
if [ ! -L /service/dbus-conext-bridge ]; then
    ln -sf "$INSTALL_DIR/service" /service/dbus-conext-bridge
    logger "conext-bridge: Service linked"
fi

# 2. Register DBUS settings (idempotent)
$DBUS_CMD AddSetting ConextBridge GatewayIp "192.168.1.223" s 0 0 2>/dev/null || true
$DBUS_CMD AddSetting ConextBridge GatewayPort 503 i 1 65535 2>/dev/null || true
$DBUS_CMD AddSetting ConextBridge UnitIds "11,12" s 0 0 2>/dev/null || true
$DBUS_CMD AddSetting ConextBridge UnitCount 2 i 1 4 2>/dev/null || true
$DBUS_CMD AddSetting ConextBridge PollInterval 3000 i 1000 30000 2>/dev/null || true
$DBUS_CMD AddSetting ConextBridge RestartRequested 0 i 0 1 2>/dev/null || true

# 3. Deploy QML settings page (survives firmware updates)
if [ -d "$QML_DIR" ] && [ -f "$INSTALL_DIR/gui/PageSettingsConextBridge.qml" ]; then
    cp "$INSTALL_DIR/gui/PageSettingsConextBridge.qml" "$QML_DIR/"
    if [ -f "$QML_DIR/PageSettings.qml" ] && ! grep -q ConextBridge "$QML_DIR/PageSettings.qml"; then
        cp "$QML_DIR/PageSettings.qml" "$QML_DIR/PageSettings.qml.orig.conext"
        python3 -c "
p=\"/opt/victronenergy/gui/qml/PageSettings.qml\"
with open(p) as f: lines=f.readlines()
entry=\"\\n\\t\\tMbSubMenu {\\n\\t\\t\\tdescription: qsTr(\\\"Conext Bridge\\\")\\n\\t\\t\\tsubpage: Component { PageSettingsConextBridge {} }\\n\\t\\t}\\n\"
lines.insert(-2, entry)
with open(p,\"w\") as f: f.writelines(lines)
" 2>/dev/null && logger "conext-bridge: QML patched"
    fi
fi

logger "conext-bridge: Setup complete"
