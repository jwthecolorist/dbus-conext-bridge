#!/bin/sh
# Conext Bridge boot-time setup (runs on every boot via rc.local)
# Self-registers in /data/rc.local on first run — zero-touch install
INSTALL_DIR="/data/dbus-conext-bridge"
DBUS_CMD="dbus -y com.victronenergy.settings /Settings"
QML_DIR="/opt/victronenergy/gui/qml"

logger "conext-bridge: Running setup..."

# 0. Self-register in rc.local (idempotent)
if [ -f /data/rc.local ]; then
    if ! grep -q 'dbus-conext-bridge/setup.sh' /data/rc.local 2>/dev/null; then
        sed -i '/^exit 0/d' /data/rc.local
        echo "" >> /data/rc.local
        echo "# --- Conext Bridge (auto-installed) ---" >> /data/rc.local
        echo "[ -x /data/dbus-conext-bridge/setup.sh ] && /data/dbus-conext-bridge/setup.sh" >> /data/rc.local
        echo "exit 0" >> /data/rc.local
        logger "conext-bridge: Registered in rc.local"
    fi
    chmod +x /data/rc.local
else
    printf '#!/bin/sh\n# --- Conext Bridge (auto-installed) ---\n[ -x /data/dbus-conext-bridge/setup.sh ] && /data/dbus-conext-bridge/setup.sh\nexit 0\n' > /data/rc.local
    chmod +x /data/rc.local
    logger "conext-bridge: Created rc.local with setup hook"
fi

# 1. Service symlink (/service is tmpfs, recreated each boot)
if [ ! -L /service/dbus-conext-bridge ]; then
    ln -sf "$INSTALL_DIR/service" /service/dbus-conext-bridge
    logger "conext-bridge: Bridge Service linked"
fi
if [ ! -L /service/conext-poller ]; then
    ln -sf "$INSTALL_DIR/poller-service" /service/conext-poller
    logger "conext-bridge: Poller Service linked"
fi

# 2. Register DBUS settings (safe to re-run, won't overwrite existing values)
$DBUS_CMD AddSetting ConextBridge GatewayIp "192.168.1.223" s 0 0 2>/dev/null || true
$DBUS_CMD AddSetting ConextBridge GatewayPort 503 i 1 65535 2>/dev/null || true
$DBUS_CMD AddSetting ConextBridge UnitIds "11,12" s 0 0 2>/dev/null || true
$DBUS_CMD AddSetting ConextBridge UnitCount 2 i 1 4 2>/dev/null || true
$DBUS_CMD AddSetting ConextBridge PollInterval 3000 i 1000 30000 2>/dev/null || true
$DBUS_CMD AddSetting ConextBridge RestartRequested 0 i 0 1 2>/dev/null || true

# 3. Deploy QML settings page (survives firmware updates)
if [ -d "$QML_DIR" ] && [ -f "$INSTALL_DIR/gui/PageSettingsConextBridge.qml" ]; then
    cp "$INSTALL_DIR/gui/PageSettingsConextBridge.qml" "$QML_DIR/"
    # Patch PageSettings.qml menu if not already done
    if [ -f "$QML_DIR/PageSettings.qml" ] && ! grep -q ConextBridge "$QML_DIR/PageSettings.qml"; then
        cp "$QML_DIR/PageSettings.qml" "$QML_DIR/PageSettings.qml.orig.conext"
        python3 -c "
p='$QML_DIR/PageSettings.qml'
with open(p) as f: lines=f.readlines()
entry='\n\t\tMbSubMenu {\n\t\t\tdescription: qsTr(\"Conext Bridge\")\n\t\t\tsubpage: Component { PageSettingsConextBridge {} }\n\t\t}\n'
lines.insert(-2, entry)
with open(p,'w') as f: f.writelines(lines)
" 2>/dev/null && logger "conext-bridge: QML settings page patched"
    fi
fi

logger "conext-bridge: Setup complete"
